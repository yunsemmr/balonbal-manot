function yesOption() {
    // Yeşil butona tıklandığında yönlendirme
    window.location.href = "affettin.html";
}

function noOption() { 
    // Kırmızı butona tıklandığında yönlendirme
    window.location.href = "affetmedin.html";
}
